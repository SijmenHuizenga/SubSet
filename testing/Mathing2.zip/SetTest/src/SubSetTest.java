import java.util.HashSet;
import java.util.TreeSet;

public class SubSetTest {
	
	public SubSetTest() {
		String[][] stapels = new String[9][];
		for (int i = 0; i < stapels.length; i++) {
			stapels[i] = maakStapel();
		}
		
		HashSet<TreeSet<String>> groepjes = new HashSet<>();
		int tot = 0;
		for(String a : stapels[0]){
			TreeSet<String> newGroep = new TreeSet<>();
			newGroep.add(a);
			for(String b : stapels[1]){
				if(!newGroep.add(b))
					continue;
				for(String c : stapels[2]){
					if(!newGroep.add(c))
						continue;
					for(String d : stapels[3]){
						if(!newGroep.add(d))
							continue;
						for(String e : stapels[4]){
							if(!newGroep.add(e))
								continue;
							for(String f : stapels[5]){
								if(!newGroep.add(f))
									continue;
								for(String g : stapels[6]){
									if(!newGroep.add(g))
										continue;
									for(String h : stapels[7]){
										if(!newGroep.add(h))
											continue;
										for(String i : stapels[8]){
											if(!newGroep.add(i))
												continue;
											groepjes.add(newGroep);
											tot++;
											if(tot % 1000000 == 0){
												System.out.println("nu " + tot/1000000 + " miljoen groepen van 9 langs zien komen");
												System.out.println("Nu zijn er " + groepjes.size() + " uniqe groepjes gevonden.");
											}
											newGroep.remove(i);
										}
										newGroep.remove(h);
									}
									newGroep.remove(g);
								}
								newGroep.remove(f);
							}
							newGroep.remove(e);
						}
						newGroep.remove(d);
					}
					newGroep.remove(c);
				}
				newGroep.remove(b);
			}
		}
		
		for(TreeSet<String> groep : groepjes){
			System.out.println(groep);
		}
		
	}
	
	String[] maakStapel() {
		String[] out = new String[27];
		int i = 0;
		for (char v : "RBY".toCharArray()) {
			for (char t : "OGP".toCharArray()) {
				for (char k : "EQT".toCharArray()) {
					out[i] = "" + v + t + k;
					i++;
				}
			}
		}
		return out;
	}
	
	public static void main(String[] args) {
		new SubSetTest();
	}
}
