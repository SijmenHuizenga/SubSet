package sijmen.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

//aantal sets is !n/(!k*!(n-k)) n = 27, k = 2
//n is aantal kaarten
//k is aantal sets

public class SetTest {

	String[] stapel1;
	String[] stapel2;
	String[] stapel3;
	
	public SetTest(){
		stapel1 = maakStapel();
		stapel2 = maakStapel();
		stapel3 = maakStapel();
		
		HashSet<ArrayList<String>> groepjes = new HashSet<>();
		int sets = 0;
		int tot = 0;
		for(String a : stapel1){
			for(String b : stapel2){
				for(String c : stapel3){
					ArrayList<String> newGroep = new ArrayList<>();
					newGroep.add(a);
					newGroep.add(b);
					newGroep.add(c);
					Collections.sort(newGroep);
					groepjes.add(newGroep);
					tot ++;
				}
			}
		}
		for(ArrayList<String> asdf : groepjes){
			if(isSet(asdf.get(0), asdf.get(1), asdf.get(2))){
				sets++;
			}
		}
		System.out.println("gemaakte groepen van 3: " + tot);
		System.out.println("unieke groepen van 3: " + groepjes.size());
		System.out.println("sets: " + sets);
	}
	
	boolean isSet(String a, String b, String c){
		
		char[] as = a.toCharArray();
		char[] bs = b.toCharArray();
		char[] cs = c.toCharArray();
		
		int same = 0;
		for(int i = 0; i < 3; i++){
			if((as[i] == bs[i] && as[i] == cs[i]) || (as[i] != bs[i] && as[i] != cs[i] && bs[i] != cs[i]))
				same++;
		}
		
		return same == 3;
	}
	
	String[] maakStapel(){
		String[] out = new String[27];
		int i = 0;
		for(char v : "RBY".toCharArray()){
			for(char t : "OGP".toCharArray()){
				for(char k : "EQT".toCharArray()){
					out[i] = ""+v+t + k;
					i++;
				}
			}
		}
		return out;
	}
	
	public static void main(String[] args) {
		new SetTest();
	}
	
}
